# Hexley Chrome Extension

Shows Hexley's mascot on **claude.ai** and **chatgpt.com**, reacting to real gateway decisions as they happen. Lets you approve or deny held actions from the browser.

> **It does not enforce anything.** Hexley's gateway does that. The extension only shows what Hexley decided.

---

## Install (load unpacked)

1. Clone the Hexley repo (the extension is in `main`, in the `extension/` folder):
   ```bash
   git clone https://github.com/NavdeepSingh0/Sentinel.git
   cd Hexley
   ```

2. Open Chrome → `chrome://extensions` → enable **Developer mode** (top-right toggle).

3. Click **Load unpacked** → select the `extension/` folder inside the repo.

4. The Hexley icon appears in your toolbar. (The extension has its own pixel mascot, `extension/pixel-mascot.js`. Its art and the icons are written by `python design/brand/make_brand.py`; after the art changes, run that and reload the extension.)

---

## Pairing with Hexley

1. Start Hexley:
   ```bash
   python -m pip install --user uv
   python -m uv sync
   npm --prefix site ci && npm --prefix site run build
   npm --prefix console ci && npm --prefix console run build
   python -m uv run python -m sentinel up --demo
   ```

2. Copy the full link it prints — looks like:
   ```
   http://127.0.0.1:8000/#token=hARp2Ku-JPSqzBdaWGdYZGCQ-...
   ```

3. Click the Hexley toolbar icon → **Settings** → paste the full link → **Save & test**.

4. "Connected" appears — the mascot is now live.

---

## What the mascot shows

The mascot's own movement is drawn for a large mascot, so at this small size it is subtle. The overlay adds a slow float while it waits (faster while it checks), a pop when something is allowed or verified, and a shake when something is denied, quarantined or tampered with. If your system asks for reduced motion (Windows: Settings, Accessibility, Visual effects, Animation effects), all movement is switched off and the mascot shows a still pose.

| State | Meaning |
|---|---|
| `sleeping` | No active Hexley session |
| `idle` | Session active, waiting |
| `checking` | Evaluating an AI action |
| `allowed` | Action permitted (green, 1.5 s) |
| `denied` | Action blocked (blue) |
| `needs-approval` | Waiting for your decision (amber) |
| `quarantined` | Session frozen — too many violations |
| `verified` | Audit log confirmed intact |
| `tamper` | Audit log has been altered |

---

## Approving / denying held actions

When the mascot shows **needs-approval**:

1. A **Review** button appears on the mascot overlay.
2. Click it to see the tool, its arguments, and the time left.
3. **Approve** (requires a second click to confirm) or **Deny** (one click).
4. The result appears in the Hexley console audit log.

---

## Permissions

| Permission | Why |
|---|---|
| `storage` | Saves your Hexley address and token (session only by default) |
| `http://127.0.0.1/*` | Reach a locally-running Hexley |
| `http://localhost/*` | Same |
| `https://claude.ai/*` | Inject the mascot overlay |
| `https://chatgpt.com/*` | Inject the mascot overlay |

**How it is tested:** `scripts/extension_qa.mjs` loads the extension into Chromium against a running Hexley and checks the overlay, approving from the browser, the per-site switch and the local-address rule (the header of the script says what it needs).

**Hexley must run on this computer.** The officer token can approve actions, so the extension only sends it to `http://127.0.0.1` or `http://localhost` (the options page refuses any other address). A tunnel address does not help: Hexley's tunnel reaches the AI gateway, not the officer API.

**What this extension does NOT do:**
- Does not read your chat, prompts, or files
- Does not send any data anywhere except to your configured Hexley address
- Does not enforce or block anything

---

## Updating the mascot

The art and icons come from one script. Change the grid there and run it:

```bash
python design/brand/make_brand.py
```

The faces for each state are in `extension/pixel-mascot.js`.

Then reload the extension on `chrome://extensions`.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Not configured" | Open Settings and paste the Hexley link |
| "Token rejected" | Restart Hexley (`up --demo`) and paste the new link |
| "Hexley not connected" | Make sure `sentinel up --demo` is running |
| Mascot not visible on claude.ai | Check that the site toggle is on in the popup |
| 409 on approve/deny | The approval expired or was already resolved — check the console |
| "Use the address of Hexley on this computer" | Paste the link that `sentinel up` prints (it starts with `http://127.0.0.1`) |

